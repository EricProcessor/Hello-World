<template>
 <div>
     <ul>
         <li>
             <router-link to="/">helloworld</router-link>
             <router-link to="/hello">hello</router-link>
         </li>
         <li></li>
     </ul>
 </div>
</template>

<script>
 export default {
   data () {
     return {

     }
   },
   components: {

   }
 }
</script>

<style>

 
</style>
