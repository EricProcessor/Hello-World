<template>
 <div>
        my name is Eric
 </div>
</template>

<script>
 export default {
   data () {
     return {

     }
   },
   components: {

   }
 }
</script>

<style>

 
</style>
